import { Component, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-input-box',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './input-box.component.html',
  styleUrls: ['./input-box.component.scss']
})
export class InputBoxComponent {
  @Output() submitMessage = new EventEmitter<string>();
  userInput = '';

  send() {
    if (this.userInput.trim()) {
      this.submitMessage.emit(this.userInput);
      this.userInput = '';
    }
  }
}
