import { Component, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InputBoxComponent } from '../input-box/input-box.component';
import { ProductCardComponent } from '../product-card/product-card.component';
import { RatingStarsComponent } from '../rating-stars/rating-stars.component';

@Component({
  selector: 'app-chatbot',
  standalone: true,
  imports: [CommonModule, InputBoxComponent, ProductCardComponent, RatingStarsComponent],
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent {
  isOpen = false;
  isLoggedIn = false;
  messages: { text: any; sender: 'user' | 'bot' }[] = [];
  @ViewChild('scrollMe') scrollMe!: ElementRef;

  toggleChat() {
    this.isOpen = !this.isOpen;
  }

  toggleLogin() {
    this.isLoggedIn = !this.isLoggedIn;
    this.messages = [];
  }

  async handleUserMessage(msg: string) {
    this.messages.push({ text: msg, sender: 'user' });
    this.messages.push({ text: 'Loading', sender: 'bot' });

    const apiUrl = this.isLoggedIn
      ? `http://127.0.0.1:5000/recommendations/azure/linda?question=${msg}`
      : `http://127.0.0.1:5000/recommendations/azure?question=${msg}`;

    try {
      const res = await fetch(apiUrl);
      const data = await res.json();
      this.messages[this.messages.length - 1] = { text: data, sender: 'bot' };
      this.scrollToBottom();
    } catch (e) {
      this.messages[this.messages.length - 1] = { text: 'Error fetching response', sender: 'bot' };
    }
  }

  scrollToBottom() {
    setTimeout(() => {
      this.scrollMe?.nativeElement.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }
}
