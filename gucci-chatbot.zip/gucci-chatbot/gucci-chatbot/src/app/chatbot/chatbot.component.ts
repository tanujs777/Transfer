import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-chatbot',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent {
  isOpen = true;
  userInput = '';
  messages: string[] = ['Bot: Hi! Guest, How can I assist you today?'];

  toggleChat() {
    this.isOpen = !this.isOpen;
  }

  sendMessage() {
    if (!this.userInput.trim()) return;

    const userMsg = `You: ${this.userInput}`;
    this.messages.push(userMsg);
    this.userInput = '';

    setTimeout(() => {
      this.messages.push(`Bot: Thanks for your message.`);
    }, 600);
  }
}
