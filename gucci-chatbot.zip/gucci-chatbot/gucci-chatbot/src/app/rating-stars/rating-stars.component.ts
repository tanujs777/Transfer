import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-rating-stars',
  standalone: true,
  imports: [CommonModule],
  template: `
    <span *ngFor="let star of stars">
      <ng-container [ngSwitch]="star">
        <span *ngSwitchCase="'full'">★</span>
        <span *ngSwitchCase="'half'">☆</span>
        <span *ngSwitchDefault>✩</span>
      </ng-container>
    </span>
  `,
  styles: [`
    span {
      color: gold;
      font-size: 12px;
      margin-right: 2px;
    }
  `]
})
export class RatingStarsComponent {
  @Input() rating = 0;
  stars: ('full' | 'half' | 'empty')[] = [];

  ngOnChanges() {
    this.stars = Array.from({ length: 5 }, (_, i) => {
      const full = i + 1 <= this.rating;
      const half = i + 1 > this.rating && i < this.rating;
      return full ? 'full' : half ? 'half' : 'empty';
    });
  }
}
