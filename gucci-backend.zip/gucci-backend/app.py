from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
from gucci_prompter import get_gemini_response

load_dotenv()

app = Flask(__name__)
CORS(app)

@app.route("/recommendations/azure", methods=["GET"])
@app.route("/recommendations/azure/linda", methods=["GET"])
def recommend():
    user_input = request.args.get("question", "")
    if not user_input:
        return jsonify({"error": "Missing 'question' parameter"}), 400

    try:
        response = get_gemini_response(user_input)
        # Expect JSON response from Gemini — fallback to plain text if malformed
        try:
            parsed = eval(response) if response.strip().startswith("[") else {"Note": response}
        except Exception:
            parsed = {"Note": response}
        return jsonify(parsed)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
