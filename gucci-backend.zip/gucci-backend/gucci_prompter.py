import os
import pandas as pd
import vertexai
from vertexai.generative_models import GenerativeModel

def init_vertex():
    vertexai.init(project=os.getenv("PROJECT_ID"), location=os.getenv("REGION"))
    return GenerativeModel(os.getenv("MODEL_ID"))

def process_excel():
    df = pd.read_excel("data/BB_Sample.xlsx")
    return df.head(5).to_dict(orient="records")  # Use top 5 for prompt

def build_prompt(user_input, product_data):
    return f"""
You are a helpful product assistant for Gucci. A customer asked:

"{user_input}"

Based on the following product data, suggest only the most relevant products:

{product_data}

Only return products that match their needs. If nothing matches, respond with: "No relevant products found at the moment."
"""

def get_gemini_response(user_input):
    model = init_vertex()
    product_data = process_excel()
    prompt = build_prompt(user_input, product_data)
    response = model.generate_content(prompt)
    return response.text
